# easyui扩展

## jquery.datagrid.ext

```
var row = $('#tt').datagrid('getRow',index); 通过行索引获取对象

```

## jquery.form.ext

```
var data = $('#tt').form('getData'); 获取表单数据，json形式
```

## jquery.tree.ext

```
获取勾选的id，返回数组
var idArr = $('#tree').tree('getCheckedId');
var idArr = $('#tree').tree('getCheckedId','code');
```

